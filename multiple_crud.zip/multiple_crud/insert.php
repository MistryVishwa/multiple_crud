<!-- add connection -->
<?php
include_once('connection.php');
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Insert multiple rows using PHP</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="container">
    <br/>
    <table width="70%" border="0" align="center" id="v_tbl">
      <tr>
        <td>
          <h3>Insert Data</h3>
          <div class="text-center">
            <button class="btn btn-danger mt-2 mb-2" onclick="addMore()">Add More</button>
          </div>
        </td>
      </tr>
      <tr>
        <td>
          <form action="edit.php" method="post" autocomplete="off">
            <table width="100%" id="formTable">
              <tr>
                <td align="center">
                  <input type="text" name="name[]" placeholder="Enter Name" class="form-control" id="name" required> <br>
                  <input type="tel" maxlength="10" name="phone[]" placeholder="Enter Phone Number" class="form-control" id="phone" required> <br>
                  <input type="email" name="email[]" placeholder="Enter Email" class="form-control" id="email" required> <br>
                  <hr>
                </td>
              </tr>
            </table>
            <button type="submit" name="btn_datainsert" class="btn btn-primary btn-block mt-2">Save Data</button>
          </form>
        </td>
      </tr>
    </table>
  </div>

  <script>
    function addMore() {
      var table = document.getElementById("formTable");
      var row = table.insertRow(table.rows.length);
      var cell = row.insertCell(0);
      cell.innerHTML = '<input type="text" name="name[]" placeholder="Enter Name" class="form-control" required id="name' + table.rows.length + '"> <br>' +
        '<input type="tel" name="phone[]" maxlength="10" placeholder="Enter Phone Number" class="form-control" required id="phone' + table.rows.length + '"> <br>' +
        '<input type="email" name="email[]" placeholder="Enter Email" class="form-control" required id="email' + table.rows.length + '"> <br>' +
        '<hr>'; 
    }
  </script>
</body>
</html>
