<!-- add connection -->
<?php
include_once('connection.php');

// insert data
if(isset($_POST['btn_datainsert']))
{
  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];

  foreach($name as $list => $names)
  {
      $s_name = $names;
      $s_phone = $phone[$list];
      $s_email = $email[$list];

      // insert query
      $query = "INSERT INTO posts (name, phone, email) VALUES ('$s_name','$s_phone','$s_email')";
      $query_run = mysqli_query($conn, $query);
  }
  if($query_run)
  {
      echo "Data Inserted Successfully";
      header("Location: list.php");
  }
  else
  {
      echo "Data Not Inserted";
      header("Location: insert.php");
  }
}

// delete data
if (isset($_POST['btn_delete'])) 
{
  unset($_POST['btn_delete']);
  $delete_ids = $_POST['deleteid'];
  $totaldeleteid = count($_POST['deleteid']);
  if ($totaldeleteid == "") 
  {
    echo "<script>alert('Sorry No Record Found');window.location.href = 'list.php';</script>";
    exit;
  }
  foreach ($delete_ids as $key => $val) 
  {
    $delete_que = "DELETE from `posts` WHERE `id`='$val'";
    mysqli_query($conn, $delete_que); 
  }
  header("Location:list.php");
  exit;
}
if (isset($_POST['btn_edit'])) 
{
  unset($_POST['btn_edit']);
  $edit_ids = $_POST['editid'];
  $totaledit_ids = count($_POST['editid']);
}

// update data
if (isset($_POST['btn_dataupdate'])) 
{
  unset($_POST['btn_dataupdate']);
  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];
  $iddds = $_POST['iddd'];
  $count = count($_POST['iddd']);

  for ($i = 0; $i < $count; $i++) 
  {
    $update_que = "UPDATE `posts` SET name='$name[$i]',phone='$phone[$i]',email='$email[$i]' WHERE `id`='$iddds[$i]'";
    mysqli_query($conn, $update_que); 
  }
  header("Location:list.php");
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Edit & Delete multiple rows using PHP</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="container">
  <br/>
    <table width="70%" border="0" align="center" id="v_tbl">
      <tr>
          <td>
              <h3>TOTAL EDIT IDS "
                <?php echo $totaledit_ids; 
                  if($totaledit_ids=="")
                  {
                    echo "<script>alert('Sorry No Record Found');window.location.href = 'list.php';</script>";
                  }
                ?>" 
              </h3>
          </td>
      </tr>
      <tr>
        <td>
          <form action="edit.php" method="post" autocomplete="off">
            <?php
              $j = 0;
              foreach ($edit_ids as $key => $val) 
              {
                $view_que = "SELECT * FROM `posts` WHERE `id`='$val'";
                $result = mysqli_query($conn, $view_que);
                while ($row = mysqli_fetch_assoc($result)) 
                {
                  ?>
                    <table width="100%">
                      <tr>
                        <td align="left">
                            <input type="text" name="" value="<?php echo ++$j; ?>" class="form-control" readonly="true" id="slno">
                        </td>
                        <td align="center">
                          <input type="hidden" name="iddd[]" value="<?= htmlspecialchars($row['id']); ?>">
                          <b class="form-control">ID-<?= htmlspecialchars($row['id']); ?></b>
                          <input type="text" name="name[]" placeholder="Enter Name" value="<?= htmlspecialchars($row['name']); ?>" class="form-control" id="name" required>
                          <input type="tel" name="phone[]" maxlength="10" placeholder="Enter Phone Number" value="<?= htmlspecialchars($row['phone']); ?>" class="form-control" id="phone" required>
                          <input type="email" name="email[]" placeholder="Enter Email" value="<?= htmlspecialchars($row['email']); ?>" class="form-control" id="email" required>
                        </td>
                        <br><hr>
                      </tr>
                    </table>
                  <?php
                }
              }
            ?>
            <button type="submit" name="btn_dataupdate" id="btn_dataupdate" class="btn btn-primary btn-block mt-2">Update Data</button>
          </form>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>
   