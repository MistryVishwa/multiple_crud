<!-- add connection   -->
<?php
include_once('connection.php');
?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Multiple Crud In PHP</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- fafa icon cdn -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
   <br/>
      <div class="col-sm-12">
        <h3 align="center">Edit & Delete Multiple Rows Using PHP</h3>
        <br/>  
        <div class="search-box">
            <div class="input-group mb-2">
               <div class="input-group-prepend">
                     <span class="input-group-text"><i class="fas fa-search"></i></span>
               </div>
               <input type="text" class="form-control" id="searchInput" placeholder="Search Here...">
            </div>
         </div>
         <form action="edit.php" method="POST">
            <table width="100%" class="table table-striped tablevk" >
               <thead>
                  <tr>
                     <th width="20%" align="center">Sr No</th>  
                     <th width="20%" align="center">Name</th>
                     <th width="20%" align="center">Phone</th>
                     <th width="20%" align="center">Email Id</th>
                     <th width="20%" align="center">
                        <div class="row">
                           <div class="col-sm-5" id="edit_div" style="margin-left: -13px;">
                              Edit-<input type='checkbox' id='EditAll' autocomplete="off" >
                           </div>
                           <div class="col-sm-6" id="dalete_div">
                              Delete-<input type='checkbox' id='DeleteAll' autocomplete="off">
                           </div>
                        </div>
                     </th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                     $i=1;   
                     $sql2="SELECT * FROM posts";
                     $result = mysqli_query($conn, $sql2);
                     while ($row = mysqli_fetch_assoc($result)) 
                     {
                        ?>
                        <tr>
                           <td width="20%" align="left"><?php echo $i++;?></td>
                           <td width="20%" align="left"><?php echo $row['name'];?></td>
                           <td width="20%" align="left"><?php echo $row['phone'];?></td>
                           <td width="20%" align="left"><?php echo $row['email'];?></td>
                           <td width="20%" align="left">
                              <div class="row">
                                 <div class="col-sm-5" id="edit_div">
                                    Edit-<input type="checkbox" class="edit_customer" name="editid[]"  value="<?php echo $row['id'];?>" autocomplete="off"/>
                                 </div>
                                 <div class="col-sm-6" id="dalete_div">
                                    Delete-<input type="checkbox" class="delete_customer" name="deleteid[]"  value="<?php echo $row['id'];?>" autocomplete="off"/>
                                 </div>
                              </div>         
                           </td>
                        </tr>
                        <?php  
                     }  
                  ?>
               </tbody>
               <tfoot>
                  <tr>
                     <th width="20%" align="center"></th>  
                     <th width="20%" align="center"></th>
                     <th width="10%" align="center"></th>
                     <th width="20%" align="center">
                        <div class="row">
                           <div class="col-sm-4">
                              <a href="insert.php" id="btn_edit" class="btn btn-danger">Insert</a>
                           </div>
                           <div class="col-sm-4">
                              <button type="submit" name="btn_edit" id="btn_edit" class="btn btn-danger">Edit</button>
                           </div>
                           <div class="col-sm-4">
                              <button type="submit" name="btn_delete" id="btn_delete" class="btn btn-danger">Delete</button>
                           </div>
                        </div>
                     </th>
                  </tr>
               </tfoot>
            </table>
        </form> 
    </div>
</div>
</body>
<script>
   $(document).ready(function () {
      $('#DeleteAll').on('click', function () {
         if ($('#DeleteAll:checked').length == $('#DeleteAll').length) 
         {
            $('.delete_customer').prop('checked', true);
         }
         else 
         {
            $('.delete_customer').prop('checked', false);
         }
      });

      $('#EditAll').on('click', function () 
      {
         if ($('#EditAll:checked').length == $('#EditAll').length) 
         {
            $('.edit_customer').prop('checked', true);
         } 
         else 
         {
            $('.edit_customer').prop('checked', false);
         }
      });

      $('#searchInput').on('keyup', function () 
      {
         var searchText = $(this).val().toLowerCase();

         $('table tbody tr').each(function () 
         {
            var rowText = $(this).text().toLowerCase();
            if (rowText.indexOf(searchText) === -1) 
            {
            $(this).hide();
            } 
            else 
            {
            $(this).show();
            }
         });
      });
   });
</script>
</html>